use std::{
    collections::HashSet,
    sync::{LazyLock, Mutex},
    time::Duration,
};

use axum::{extract::State, http::StatusCode, response::IntoResponse, Extension, Json};
use serde::Serialize;
use serde_json::{json, Value};
use sqlx::PgPool;
use tokio::task::JoinSet;
use utoipa::ToSchema;

use crate::auth::middleware::AuthUser;

const MAX_CONCURRENT_PREPARATIONS: usize = 2;
static PREPARING_TICKERS: LazyLock<Mutex<HashSet<String>>> =
    LazyLock::new(|| Mutex::new(HashSet::new()));

#[derive(Serialize, ToSchema)]
pub struct ShareTrendItem {
    pub ticker: String,
    pub available: bool,
    pub signal: Option<String>,
    pub condition: Option<String>,
    pub rsi: Option<f64>,
    pub horizon_days: Option<i64>,
    pub last_close: Option<f64>,
    pub predicted_close: Option<f64>,
    pub as_of: Option<String>,
    pub model: Option<String>,
    pub model_version: Option<String>,
    pub reason: Option<String>,
    pub retryable: bool,
}

#[derive(Serialize, ToSchema)]
pub struct ListTrendsResponse {
    pub trends: Vec<ShareTrendItem>,
}

#[utoipa::path(
    get,
    path = "/user/shares/trends",
    responses(
        (status = 200, description = "Trend prediction (Modal) for each stock declared by the authenticated user", body = ListTrendsResponse, example = json!({
            "trends": [
                {
                    "ticker": "GGAL",
                    "available": true,
                    "signal": "alza",
                    "condition": "neutral",
                    "rsi": 58.3,
                    "horizon_days": 5,
                    "last_close": 8365.0,
                    "predicted_close": 8511.82,
                    "as_of": "2026-06-17",
                    "model": "lstm",
                    "model_version": "lstm-20260618T003942Z",
                    "reason": null
                },
                {
                    "ticker": "YPFD",
                    "available": false,
                    "signal": null,
                    "condition": null,
                    "rsi": null,
                    "horizon_days": null,
                    "last_close": null,
                    "predicted_close": null,
                    "as_of": null,
                    "model": null,
                    "model_version": null,
                    "reason": "No se pudo contactar a api-ml"
                }
            ]
        })),
        (status = 401, description = "Missing or invalid authentication token", example = json!({
            "code": 401,
            "message": "Invalid or expired token"
        })),
        (status = 500, description = "Internal server error", example = json!({
            "code": 500,
            "message": "An unexpected error occurred. Please try again later."
        }))
    ),
    security(("bearer_auth" = [])),
    tag = "Share"
)]
pub async fn handler(
    State(pool): State<PgPool>,
    Extension(auth_user): Extension<AuthUser>,
) -> impl IntoResponse {
    let tickers = sqlx::query_as::<_, (String,)>(
        r#"
        SELECT DISTINCT s.ticker
        FROM user_shares us
        JOIN shares s ON s.id = us.share_id
        WHERE us.user_id = $1
        ORDER BY s.ticker ASC
        "#,
    )
    .bind(auth_user.user_id)
    .fetch_all(&pool)
    .await;

    let tickers = match tickers {
        Ok(rows) => rows.into_iter().map(|(ticker,)| ticker).collect::<Vec<_>>(),
        Err(err) => {
            tracing::error!("Failed to list tickers for trends: {}", err);
            return (
                StatusCode::INTERNAL_SERVER_ERROR,
                Json(json!({
                    "code": 500,
                    "message": "An unexpected error occurred. Please try again later."
                })),
            );
        }
    };

    let mut trends = Vec::with_capacity(tickers.len());
    if !tickers.is_empty() {
        // Las predicciones solo cambian una vez por rueda (as_of es diario): servir
        // desde cache lo pedido hoy evita pegarle a Modal en vivo en cada carga de
        // pantalla, que es lo que hacia notablemente lento el listado (issue #180).
        let cached: Vec<(String, Value)> = sqlx::query_as::<_, (String, Value)>(
            r#"
            SELECT ticker, payload
            FROM ticker_trend_cache
            WHERE ticker = ANY($1) AND fetched_at::date = CURRENT_DATE
            "#,
        )
        .bind(&tickers)
        .fetch_all(&pool)
        .await
        .unwrap_or_else(|error| {
            tracing::error!("No se pudo leer la cache de tendencias: {}", error);
            Vec::new()
        });
        let cached_tickers: HashSet<String> =
            cached.iter().map(|(ticker, _)| ticker.clone()).collect();
        trends.extend(cached.into_iter().map(|(_, payload)| payload));

        let to_fetch: Vec<String> = tickers
            .into_iter()
            .filter(|ticker| !cached_tickers.contains(ticker))
            .collect();

        if !to_fetch.is_empty() {
            let modal_lstm_url = std::env::var("MODAL_LSTM_URL").unwrap_or_else(|_| {
                "https://matimorales01--lstm-trend-model-main.modal.run".into()
            });
            // El proxy de Render puede cortar la request antes que un cold start de
            // Modal. Cortamos nosotros primero para responder 200 con cada ticker
            // en estado "preparando" y no perder CORS con un 502 del proxy.
            let client = reqwest::Client::builder()
                .timeout(Duration::from_secs(20))
                .build()
                .expect("reqwest client");
            let mut requests = JoinSet::new();
            for ticker in to_fetch {
                let client = client.clone();
                let modal_lstm_url = modal_lstm_url.clone();
                requests.spawn(async move {
                    let trend = fetch_trend(&client, &modal_lstm_url, &ticker).await;
                    if needs_preparation(&trend) && prepare_models_in_background(&ticker) {
                        discover_ticker_for_training(&ticker);
                    }
                    trend
                });
            }
            while let Some(result) = requests.join_next().await {
                match result {
                    Ok(trend) => {
                        if trend.get("available").and_then(Value::as_bool) == Some(true) {
                            if let Some(ticker) = trend.get("ticker").and_then(Value::as_str) {
                                if let Err(error) = sqlx::query(
                                    r#"
                                    INSERT INTO ticker_trend_cache (ticker, payload, fetched_at)
                                    VALUES ($1, $2, now())
                                    ON CONFLICT (ticker)
                                    DO UPDATE SET payload = EXCLUDED.payload, fetched_at = EXCLUDED.fetched_at
                                    "#,
                                )
                                .bind(ticker)
                                .bind(&trend)
                                .execute(&pool)
                                .await
                                {
                                    tracing::error!(
                                        "No se pudo guardar la cache de tendencia para {}: {}",
                                        ticker,
                                        error
                                    );
                                }
                            }
                        }
                        trends.push(trend);
                    }
                    Err(error) => tracing::error!("Fallo una consulta de tendencia: {}", error),
                }
            }
        }

        trends.sort_by(|left, right| {
            left.get("ticker")
                .and_then(Value::as_str)
                .cmp(&right.get("ticker").and_then(Value::as_str))
        });
    }

    (StatusCode::OK, Json(json!({ "trends": trends })))
}

/// Dispara el bootstrap en Modal sin hacer esperar al request del usuario.
/// Los endpoints son idempotentes: si el artefacto ya existe no reentrenan.
fn prepare_models_in_background(ticker: &str) -> bool {
    let ticker = ticker.to_owned();
    {
        let mut preparing = PREPARING_TICKERS.lock().expect("preparing tickers lock");
        if preparing.contains(&ticker) || preparing.len() >= MAX_CONCURRENT_PREPARATIONS {
            return false;
        }
        preparing.insert(ticker.clone());
    }
    let lstm_url = std::env::var("MODAL_LSTM_PREPARE_URL")
        .unwrap_or_else(|_| "https://matimorales01--lstm-trend-model-prepare.modal.run".into());
    let xgboost_url = std::env::var("MODAL_XGBOOST_PREPARE_URL")
        .unwrap_or_else(|_| "https://matimorales01--xgboost-trend-model-prepare.modal.run".into());
    tokio::spawn(async move {
        let client = reqwest::Client::builder()
            .timeout(Duration::from_secs(7200))
            .build()
            .expect("reqwest client");
        let (lstm, xgboost) = tokio::join!(
            client.get(&lstm_url).query(&[("ticker", &ticker)]).send(),
            client
                .get(&xgboost_url)
                .query(&[("ticker", &ticker)])
                .send(),
        );
        for (model, result) in [("lstm", lstm), ("xgboost", xgboost)] {
            match result {
                Ok(response) if response.status().is_success() => {
                    tracing::info!("Bootstrap {} completado para {}", model, ticker);
                }
                Ok(response) => tracing::warn!(
                    "Bootstrap {} fallo para {}: HTTP {}",
                    model,
                    ticker,
                    response.status()
                ),
                Err(error) => {
                    tracing::warn!("Bootstrap {} fallo para {}: {}", model, ticker, error)
                }
            }
        }
        PREPARING_TICKERS
            .lock()
            .expect("preparing tickers lock")
            .remove(&ticker);
    });
    true
}

/// Si un ticker de la cartera aun no tiene artefacto, pide su historico en
/// background. data-colector lo incorpora al catalogo cuando tiene suficientes
/// ruedas y los cron diarios de Modal lo entrenan sin listas hardcodeadas.
fn discover_ticker_for_training(ticker: &str) {
    let ticker = ticker.to_owned();
    let collector = std::env::var("DATA_COLLECTOR_URL")
        .unwrap_or_else(|_| "https://data-colector.onrender.com".into());
    tokio::spawn(async move {
        let result = reqwest::Client::builder()
            .timeout(Duration::from_secs(90))
            .build()
            .expect("reqwest client")
            .post(format!(
                "{}/historical-data/{}",
                collector.trim_end_matches('/'),
                ticker
            ))
            .send()
            .await;
        match result {
            Ok(response) if response.status().is_success() => {
                tracing::info!("Historico solicitado para descubrir ticker {}", ticker);
            }
            Ok(response) => tracing::warn!(
                "No se pudo descubrir ticker {}: data-colector respondio {}",
                ticker,
                response.status()
            ),
            Err(error) => {
                tracing::warn!("No se pudo descubrir ticker {}: {}", ticker, error);
            }
        }
    });
}

/// Pide la tendencia de un ticker al LSTM productivo de Modal. Si falla (caido, timeout, ticker
/// sin modelo entrenado, etc.) no corta el resto: devuelve un item marcado
/// como no disponible en vez de tirar 500 para todos los demas tickers.
pub(crate) async fn fetch_trend(client: &reqwest::Client, modal_url: &str, ticker: &str) -> Value {
    let response = client
        .get(modal_url)
        .query(&[("ticker", ticker), ("horizon", "5")])
        .send()
        .await;

    match response {
        Ok(res) if res.status().is_success() => match res.json::<Value>().await {
            Ok(body) if body.get("error").is_none() => json!({
                "ticker": ticker,
                "available": true,
                "signal": body.get("signal"),
                "condition": body.get("condition"),
                "rsi": body.get("rsi"),
                "horizon_days": body.get("horizon_days"),
                "last_close": body.get("last_close"),
                "predicted_close": body.get("predicted_close"),
                "as_of": body.get("as_of"),
                "model": "lstm-modal",
                "model_version": body.get("model_version"),
                "reason": Value::Null,
            }),
            Ok(body) => unavailable(
                ticker,
                body.get("error")
                    .and_then(Value::as_str)
                    .unwrap_or("Modal devolvio una respuesta invalida"),
                false,
            ),
            Err(err) => {
                tracing::error!("Respuesta invalida de Modal para {}: {}", ticker, err);
                unavailable(ticker, "Respuesta invalida de Modal", true)
            }
        },
        Ok(res) => {
            tracing::warn!("Modal respondio {} para {}", res.status(), ticker);
            if res.status() == StatusCode::NOT_FOUND {
                unavailable(ticker, "Servicio de predicciones no disponible", false)
            } else {
                unavailable(ticker, "Modal no pudo predecir para este ticker", true)
            }
        }
        Err(err) => {
            tracing::error!("No se pudo contactar a Modal para {}: {}", ticker, err);
            unavailable(ticker, "No se pudo contactar a Modal", true)
        }
    }
}

fn unavailable(ticker: &str, reason: &str, retryable: bool) -> Value {
    json!({
        "ticker": ticker,
        "available": false,
        "signal": Value::Null,
        "condition": Value::Null,
        "rsi": Value::Null,
        "horizon_days": Value::Null,
        "last_close": Value::Null,
        "predicted_close": Value::Null,
        "as_of": Value::Null,
        "model": Value::Null,
        "model_version": Value::Null,
        "reason": reason,
        "retryable": retryable,
    })
}

/// Un timeout o una caida de Modal no significa que falte entrenar. Solo se
/// inicia el bootstrap cuando el propio modelo confirma que no hay artefacto.
fn needs_preparation(trend: &Value) -> bool {
    trend
        .get("reason")
        .and_then(Value::as_str)
        .is_some_and(|reason| reason.contains("todavia no hay un modelo entrenado"))
}

#[cfg(test)]
mod tests {
    use super::*;
    use axum::{
        http::StatusCode,
        response::IntoResponse,
        routing::{get, post},
        Json, Router,
    };

    async fn start_stub() -> String {
        let app = Router::new()
            .route(
                "/model-error",
                get(|| async { Json(json!({"error": "todavia no hay un modelo entrenado"})) }),
            )
            .route("/invalid", get(|| async { "not-json" }))
            .route(
                "/missing",
                get(|| async { StatusCode::NOT_FOUND.into_response() }),
            )
            .route(
                "/failure",
                get(|| async { StatusCode::INTERNAL_SERVER_ERROR.into_response() }),
            )
            .route(
                "/prepare",
                get(|| async {
                    tokio::time::sleep(Duration::from_millis(100)).await;
                    StatusCode::OK
                }),
            )
            .route("/discover/{ticker}", post(|| async { StatusCode::OK }));
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let address = listener.local_addr().unwrap();
        tokio::spawn(async move { axum::serve(listener, app).await.unwrap() });
        format!("http://{address}")
    }

    #[tokio::test]
    async fn trend_client_maps_model_http_parse_and_transport_failures() {
        let _env_guard = crate::ENV_TEST_LOCK.lock().await;
        let base = start_stub().await;
        let client = reqwest::Client::new();

        let model_error = fetch_trend(&client, &format!("{base}/model-error"), "GGAL").await;
        assert_eq!(model_error["available"], false);
        assert_eq!(model_error["retryable"], false);
        assert!(needs_preparation(&model_error));

        let invalid = fetch_trend(&client, &format!("{base}/invalid"), "GGAL").await;
        assert_eq!(invalid["reason"], "Respuesta invalida de Modal");
        assert_eq!(invalid["retryable"], true);

        let missing = fetch_trend(&client, &format!("{base}/missing"), "GGAL").await;
        assert_eq!(missing["reason"], "Servicio de predicciones no disponible");
        assert_eq!(missing["retryable"], false);

        let failure = fetch_trend(&client, &format!("{base}/failure"), "GGAL").await;
        assert_eq!(failure["reason"], "Modal no pudo predecir para este ticker");
        assert_eq!(failure["retryable"], true);

        let transport = fetch_trend(&client, "http://127.0.0.1:1", "GGAL").await;
        assert_eq!(transport["reason"], "No se pudo contactar a Modal");
        assert!(!needs_preparation(&transport));

        std::env::set_var("MODAL_LSTM_PREPARE_URL", format!("{base}/prepare"));
        std::env::set_var("MODAL_XGBOOST_PREPARE_URL", format!("{base}/prepare"));
        std::env::set_var("DATA_COLLECTOR_URL", format!("{base}/discover"));
        assert!(prepare_models_in_background("COV-A"));
        assert!(!prepare_models_in_background("COV-A"));
        assert!(prepare_models_in_background("COV-B"));
        assert!(!prepare_models_in_background("COV-C"));
        discover_ticker_for_training("COV-A");
        tokio::time::sleep(Duration::from_millis(180)).await;
    }
}
